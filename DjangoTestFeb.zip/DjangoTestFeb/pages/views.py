from django.shortcuts import render
from django.http.response import HttpResponse

# Create your views here.
def home_view(*args, **kwargs):
    print(args)
    print(kwargs)
    return HttpResponse("<H1>This is First Page from Django </H1>")


def aboutus_view(request, *args, **kwargs):
    print(request.user)
    context = {
        "user" : request.user,
        "name" : "Niel Armstrong",
        "company" : "NASA",
        "logo_line" : "create more SPACE",
        "departments" : [1001, 1320, 2450, 6650, "NASA01"],
        
        }
    return render(request, "aboutus.html", context)
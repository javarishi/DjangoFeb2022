from django.shortcuts import render, get_object_or_404
from Products.models import Product
from Products.forms import ProductForm


# Create your views here.
def product_details_view(request, my_id=1):
    # obj = Product.objects.get(id=my_id)
    prod_obj = get_object_or_404(Product, id=my_id)
    context = {
       "prod" : prod_obj,
        }
    return render(request, "products.html", context)


def product_create_view(request, *args, **kwargs):
    print("product_create_view is called")
    inital_data = {
        "price" : 999.99,
        "review" : "Really easy to understand",
        
        }
    # obj = Product.objects.get(id=1)
    prod_form = ProductForm(request.POST or None, initial=inital_data)
    # prod_form = ProductForm(request.POST or None, instance=obj)
    if prod_form.is_valid():
        prod_form.save()
        prod_form = ProductForm()
    
    context = {
       "prod_form" : prod_form,
        }
    return render(request, "product_create.html", context)
from django.contrib import admin
from Products.models import Product

# Register your models here.

admin.site.register(Product)
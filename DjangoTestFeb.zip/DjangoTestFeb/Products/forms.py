

'''
Created on 03-Mar-2022

@author: Rishi
'''
from django import forms
from Products.models import Product

class ProductForm(forms.ModelForm):
    name = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'Course Name Starting with H2KInfosys'}))
    description = forms.CharField(widget=forms.Textarea(attrs=
                                                    {
                                                        'placeholder': 'description for course',
                                                        'rows' : 20,
                                                        'cols': 120,    
                                                     
                                                     }))
    class Meta:
        model = Product
        fields = [
                "name",
                "description",
                "price",
                "review",
                "promotions",
            ]

    
    def clean_name(self, *args, **kwargs):
        chk_name = self.cleaned_data.get("name")
        if 'H2KInfosys' not in chk_name: 
            raise forms.ValidationError("Name should contain H2KInfosys")
        return chk_name
    
    
    def clean_description(self, *args, **kwargs):
        chk_description = self.cleaned_data.get("description")
        if len(str(chk_description)) < 20: 
            raise forms.ValidationError("Desciption should be greater than 20 Characters")
        return chk_description
        
